const fs = require("fs");
const path = require("path");

function json(statusCode, body) {
  return {
    statusCode,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": process.env.ALLOWED_ORIGIN || "*",
      "Access-Control-Allow-Headers": "Content-Type",
      "Access-Control-Allow-Methods": "POST, OPTIONS"
    },
    body: JSON.stringify(body)
  };
}

exports.handler = async function(event) {
  if (event.httpMethod === "OPTIONS") return json(200, { ok: true });
  if (event.httpMethod !== "POST") return json(405, { error: "POST only." });

  let body;
  try {
    body = JSON.parse(event.body || "{}");
  } catch {
    return json(400, { error: "Invalid JSON." });
  }

  const question = String(body.question || "").trim();
  if (!question) return json(400, { error: "Question is required." });

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return json(500, { error: "OPENAI_API_KEY is missing in the server environment." });
  }

  const kbPath = path.join(__dirname, "knowledge-base.md");
  const knowledgeBase = fs.existsSync(kbPath)
    ? fs.readFileSync(kbPath, "utf8")
    : "Knowledge base missing.";

  const systemPrompt = `
You are AxelAi PropOS Search for Texas real estate and AxelAi PropOS project questions.

Use the embedded artifact knowledge first. Use live web search for current facts, official agency rules, TREC/HUD/CFPB updates, fees, laws, deadlines, or anything that may have changed. 
When using live web results, include clear clickable citations in the answer if citations are available.
Answer directly. For math, show the equation and final answer. For legal/regulatory questions, say this is general/exam information and cite official sources when possible. Do not claim to access a private ChatGPT thread; only use the copied artifact knowledge below.

ARTIFACT KNOWLEDGE BASE:
${knowledgeBase}
`;

  try {
    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-5.5",
        tools: [{ type: "web_search" }],
        tool_choice: "auto",
        input: [
          { role: "system", content: [{ type: "input_text", text: systemPrompt }] },
          { role: "user", content: [{ type: "input_text", text: question }] }
        ]
      })
    });

    const data = await response.json();

    if (!response.ok) {
      return json(response.status, {
        error: data?.error?.message || "OpenAI request failed."
      });
    }

    let answer = data.output_text;
    if (!answer && Array.isArray(data.output)) {
      answer = data.output
        .flatMap(item => item.content || [])
        .map(part => part.text || "")
        .join("\n")
        .trim();
    }

    const usedWeb = Array.isArray(data.output) && data.output.some(item => item.type === "web_search_call");

    return json(200, {
      answer: answer || "No answer returned.",
      usedWeb
    });
  } catch (err) {
    return json(500, { error: err.message || "Unexpected server error." });
  }
};
