
# AxelAi PropOS — Thread Artifact Knowledge Base

This knowledge base is embedded from the user's current project/thread so the search bar can answer using AxelAi PropOS materials, Texas real estate exam concepts, and uploaded/reviewed artifacts. Use this local knowledge first. Use live web search when the user asks for current law, current TREC details, updated rates/fees, recent market info, or anything that may have changed.

## AxelAi PropOS Core Identity
- Name: AxelAi PropOS / Axel AI Property Management Operating System.
- Positioning: An AI maintenance brain and building intelligence layer for multifamily real estate.
- Required wording preference: call it an application or operating system, not a demo.
- Main customer: property operators, banks, hedge funds, asset managers, property management operators, field vendors.
- Main wedge: AI maintenance orchestration, vendor coordination, repair workflow, customer/vendor operating system.
- System idea: two connected applications:
  1. Customer OS for clients/property owners/banks/operators.
  2. Vendor App for field vendors to sign in, view work, bid, upload proof, complete tasks, and get paid.

## AxelAi Customer OS Requirements
- Create customer profile.
- Add banking / escrow setup.
- Excel upload slot.
- Required upload columns: Company Name, Property Address, Priority, Repairs Needed.
- Repairs Needed dropdown should include: Pictures, Cut Yard, Vacancy Check, Lock Replacement, Eviction Clean Out, Paint, Sheetrock with location description, Floors, Roof, Masonry, Demo with location, Additions Needed, Upgrades, and add custom columns if needed.
- After spreadsheet upload, show an amendable/editable form so the client can adjust information and add pictures.
- Allow downloading a blank sample sheet, filled sample sheet, and updated finished spreadsheet.
- Include reasonable example task prices: Pictures $25, Cut yard $60, Vacancy check $20. Avoid vague "pending cost" when an example price can be shown.

## AxelAi Vendor App Requirements
- Vendor sign-in.
- Set up bank account.
- Look for available work.
- Bid or complete repair tasks.
- Vendor tasks include:
  - Pictures of home: front, sides, back.
  - Inside pictures: minimum 20 photos of specified areas.
  - Lock change.
  - Clean out.
  - Vendor quotes.
  - Plumbing.
  - Carpentry.
  - Masonry.
  - Vacancy check.
- Vendor workflow: accept/bid job, upload before/after photos, submit completion notes, submit invoice/payment information.

## AxelAi Investor / Front Section Knowledge
- AxelAi PropOS described as "The AI Maintenance Brain for Multifamily Real Estate."
- Positioning phrase: "Where leasing AI stops, AxelAi starts."
- Opportunity claim from project artifact: multifamily maintenance is a major annual spend and no AI company owns the full maintenance workflow.
- Product: multi-agent AI system for intake, diagnosis, vendor orchestration, resolution, and prevention.
- Local artifact claims include:
  - Conversational AI + computer vision can resolve a portion of issues without human dispatch.
  - Vendor orchestration selects dispatch by skill, proximity, performance, and cost.
  - Every work order trains the model/building intelligence.
  - Integrations contemplated: Yardi, RealPage, AppFolio, Entrata.
  - Economics contemplated: SaaS per unit/month, marketplace fee on work orders, high gross margin.
  - Pilot messaging: 60-day pilot, 100–200 units, founder-led onboarding.
- Avoid making unverified investor claims as fact unless clearly labeled as project-provided estimates or assumptions.

## Texas Real Estate Exam / Study Knowledge: Agency
- Agency exists when one person (agent) acts on behalf of another person (principal/client).
- Principal = person who hires and gives authority to an agent.
- Client = principal; the represented party.
- Customer = unrepresented buyer/seller/person receiving services without agency representation.
- Fiduciary relationship = trust relationship where agent places client interests first.
- OLD CAR fiduciary duties:
  - Obedience: obey lawful client instructions.
  - Loyalty: place client interests first.
  - Disclosure: reveal known material facts and give advice/opinions to the client.
  - Confidentiality: protect client confidential information.
  - Accounting: handle money and property carefully; avoid commingling/conversion.
  - Reasonable Care: protect property/legal interests; act competently.
- Types of agency:
  - Universal agency: broad/full authority to transact all matters; rare in real estate.
  - General agency: authority to bind principal in a particular business. Examples: property manager to owner, sales associate to broker.
  - Special agency / limited agency: authority for one specific transaction; real estate listing/buyer rep agreements are usually special agency. Special agent usually cannot bind principal.
- Express agency/authority: created by written or oral agreement/instructions.
- Implied/Ostensible agency: created by conduct that leads others to believe agency exists.
- Agency by ratification: principal later accepts unauthorized act.
- Agency coupled with an interest: license holder owns or has interest in property; must disclose.
- Broker responsibilities include sponsored agents' compliance with fair housing laws, promulgated forms, TRELA, advertising, disclosure. Broker is not responsible for associates' timely license renewal, CE completion, income opportunities, company car/benefits.
- Intermediary: Texas broker may represent both parties with written consent; appointed associates may give advice and opinions to their respective parties.

## Fair Housing / Civil Rights
- Civil Rights Act of 1866: prohibits discrimination based on race and color; no exceptions; lawsuits in federal court.
- Civil Rights Act of 1968 / Federal Fair Housing Act: originally race, color, religion, national origin; sex added in 1974; handicap/disability and familial status added in 1988.
- Age is not a protected class under the federal Fair Housing Act.
- Texas Fair Housing Act recognizes same protected classes as federal fair housing: race, color, religion, sex, familial status, national origin, disability.
- Texas Fair Housing Act does not list sexual orientation or gender identity statewide, though some Texas cities have local ordinances.
- Prohibited Fair Housing conduct:
  - Refuse to rent/sell/negotiate.
  - Make housing unavailable.
  - Deny availability.
  - Set different terms, conditions, privileges, services, or facilities.
  - False denial of availability.
  - Discriminatory advertising.
  - Blockbusting/panic peddling.
  - Steering/channeling.
  - Deny access to MLS or housing-related services.
- Steering/channeling: directing buyers/renters to or away from areas/properties based on protected class. Often a common fair housing complaint.
- Blockbusting/panic peddling: inducing panic selling for profit by suggesting entry/prospective entry of minority/protected persons.
- Redlining: refusal or limitation of lending in a geographic area because of location, not borrower qualifications; can implicate banks/lenders and CRA.
- Advertising rule: describe the property, not the occupant. Avoid preferences or limitations based on race, color, religion, national origin, sex, disability, familial status.
- Prohibited ad examples: "White only," "No Irish," "Good Christian home," "Near synagogue" when used as preference, "No wheelchairs," "Adults only," "No children," "Singles only."
- Shared living exception may allow "female roommate wanted."
- Senior housing/familial status exemption:
  - 62+ occupied solely by persons 62 or older; or
  - 55+ where at least 80% of occupied units have at least one person 55 or older and policy shows intent to house 55+.
- Disability protections:
  - Disabled if condition substantially limits major life activity, record of such disability, or regarded as disabled.
  - Includes hearing, mobility, visual impairments, chronic mental illness, mental disability, AIDS/AIDS-related complex, chronic alcoholism.
  - Reasonable accommodation: change to rule/policy/practice/service necessary for disabled person to use housing. Example no-pet policy must allow guide/service animal.
  - Reasonable modification: tenant may make necessary physical modifications at tenant expense, landlord may require restoration where reasonable.
  - Housing need not be available to direct threats to health/safety or current illegal drug users.
- New multifamily buildings ready for first occupancy after March 13, 1991:
  - With elevator and 4+ units: public/common areas accessible, doors/hallways wide enough for wheelchairs, accessible routes and controls, reinforced bathroom walls, usable kitchens/bathrooms.
  - Without elevator and 4+ units: standards apply to ground-floor units.
- VAMA = Voluntary Affirmative/Marketing Agreement negotiated between HUD and housing industry associations to promote equal housing opportunity.
- Fair housing complaints:
  - May be filed with Texas Workforce Commission Civil Rights Division, HUD, courts, or U.S. Attorney General.
  - HUD notifies respondent, investigates, and determines reasonable cause.
  - HUD tries conciliation.
  - Three venues: administrative hearing, federal district court, private litigation.
  - Civil penalties/damages/injunctions/attorney fees possible; no criminal penalties.
  - Private suit generally within two years of alleged violation. HUD administrative complaint often has one-year filing window; verify current requirements if asked.

## Credit / Lending / Consumer Protection
- Equal Credit Opportunity Act (ECOA): prohibits credit discrimination based on race, color, religion, national origin, sex, marital status, age, or receipt of public assistance.
- License holders can be considered arrangers of credit and covered by ECOA.
- Fair Credit Reporting Act (FCRA): protects consumers from unfair credit reporting practices and protects credit privacy; gives consumers access to reports and right to explain exceptional items; adverse action notices required when credit/insurance/employment denied or terms increased due to report.
- Community Reinvestment Act (CRA): requires federally regulated lenders to define market area and reinvest deposits in that area when practical; aimed at preventing redlining and ensuring banks serve local community credit needs.
- CFPB: agency responsible for enforcing federal consumer financial law for mortgage-related businesses and many financial institutions.
- Loan Estimate (LE): given at application or within 3 business days after loan application.
- Consummation: borrower signs final loan documents and becomes obligated under the loan.
- LTV: percentage of lower of sales price or appraised value that lender will lend.
- PMI: private mortgage insurance on high-LTV conventional loans, commonly when down payment is less than 20%.
- MIP: mortgage insurance premium tied to FHA/government-insured loans; generally insures the whole FHA loan structure, while PMI protects lender risk.
- Budget mortgage: monthly payment includes principal and interest plus 1/12 taxes and 1/12 insurance.
- Secondary mortgage market: funded by investors buying mortgages or mortgage-backed securities.
- Fannie Mae is a major secondary market participant.

## Property Management
- Property manager authority is established by a written management agreement.
- Property manager/general agent duties may include securing tenants, collecting rents, caring for premises, budgeting/expenses, hiring/supervising employees, accounts, reports.
- Property manager should know laws relating to property management.
- Operating expense example: repainting units before a new tenant moves in.
- Public building/government building: example of property not usually handled as private property management, depending on question wording.

## Texas Real Estate Law / TREC / TRELA
- TREC = Texas Real Estate Commission. Nine members: six license holders/brokers and three public members.
- A license holder who is not an attorney cannot advise a client on validity of title; that is unauthorized practice of law.
- Texas IABS = Information About Brokerage Services; presented at first substantive dialogue/communication with a party about a specific property or transaction.
- TREC promulgated forms: license holders must use them in applicable transactions except when a form is prepared by the property owner or property owner's attorney or other authorized exception.
- TREC temporary residential leases for buyer/seller temporary occupancy are for 90 days or less.
- TREC Recovery Trust Account maximum payment from fund: commonly $50,000 per transaction; verify current statutory limits when asked.
- A TREC complaint must be filed no later than 4 years after the incident, based on the prior thread answer; verify current TREC public guidance for live use.

## Real Estate Valuation / Appraisal / Concepts
- DUST = Demand, Utility, Scarcity, Transferability; characteristics of real estate value.
- Principle of substitution: buyer will not pay more than cost of purchasing a comparable substitute property.
- Principle of progression: higher-priced property can increase value of surrounding lower-priced properties.
- Sales comparison approach: commonly best approach for existing residential property.
- Functional obsolescence: loss in value due to outdated style, layout, design, or function.
- External/economic obsolescence: depreciation caused by factors outside the property such as market cycles, economic forces, political actions, neighborhood changes.
- Police power: government power to regulate property use for public health, safety, morals, and general welfare, including zoning/building codes.
- Eminent domain: government right to take private property for public use with compensation.
- Inverse condemnation: property owner sues government claiming taking/damage occurred without formal condemnation.
- CERCLA cleanup authority: federal agencies, state natural resource agencies, and Native American tribes; property owners' associations are not listed authority in prior question.
- Estate for years: leasehold estate for a definite period with definite start/end date.

## Finance / Math Formulas
- 1 acre = 43,560 square feet.
- Acres = square feet / 43,560.
- Square feet = acres × 43,560.
- Annual interest = periodic interest × number of periods per year.
- Loan/principal = annual interest / annual interest rate.
- Commission dollars = sales price × commission rate.
- Commission rate = total commission / sales price.
- Selling broker amount = total commission × selling broker split.
- Appraised value if below sales price by percentage = sales price × (1 - percentage below).
- Points: 1 point = 1% of loan amount. Total points cost = loan amount × total points percentage.
- Seller net = sales price - seller costs/commission/payoffs/etc.
- Property tax prorations and daily interest should use daily rate and number of days in period.
- Front-foot value = front feet × price per front foot.
- Area rectangle = length × width.
- Volume = length × width × height.

## Screenshot Exam Questions Stored in Thread
1. Loan amount if quarterly interest is $3,600 at 6%: $240,000. Math: $3,600×4=$14,400; $14,400/0.06=$240,000.
2. Borrower signs final loan docs and becomes obligated: Consummation.
3. Buyer will not pay more than comparable substitute: Principle of Substitution.
4. Directing buyers into/away from areas based on protected class: Steering.
5. Property manager authority established by: Management agreement.
6. Person who hires/gives authority to agent: Principal.
7. Government right to take private land for public use: Eminent domain.
8. Selling broker gets 3% on $395,600 sale: $11,868.
9. TREC temporary lease occupancy: 90 days or less.
10. 1.2 miles by 500 feet acreage: 1.2×5,280=6,336 ft; 6,336×500=3,168,000 sq ft; /43,560=72.73 acres.
11. Senior housing 90% occupied by tenants 55+: yes familial status exemption if requirements met.
12. Refusal to lend based on area/location: Redlining.
13. Three TREC members represent: the public.
14. Non-attorney license holder advising on title validity: Unauthorized practice of law.
15. Loss due to outdated style/layout/design/function: Functional obsolescence.
16. Fair Housing violations carry: civil penalties, not criminal penalties.
17. MIP vs PMI: MIP tied to FHA/government insurance; PMI on conventional high LTV and insures lender risk.
18. TREC Recovery Trust Account maximum payment in question: $50,000.
19. 100 acres in square feet: 4,356,000 sq ft.
20. P&I plus taxes and insurance monthly: Budget mortgage.
21. Secondary market funded by: Investors.
22. Lease does not require: Recording.
23. DUST: characteristics of real estate value.
24. Redlining under CRA applies to: Banks/lenders.
25. Repainting before new tenant: operating expense.
26. LTV: percentage of lower appraised value or sales price lender will lend.
27. PMI required on: high-LTV conventional loan.
28. Portion of broker/salesperson application fees goes to: Texas Real Estate Research Center.
29. LE given: at application or within 3 business days of application.
30. Higher-priced property increasing lower-priced surroundings: Principle of Progression.
31. CERCLA authority not including: property owners' associations.
32. IABS: Information About Brokerage Services.
33. Existing residential value approach: Sales comparison approach.
34. Civil Rights Act/Fair Housing Act year: 1968.
35. 2 discount points + 1 origination point on $160,000 loan: $4,800.
36. $325,000 sale, 5.5% commission, selling broker 60%: $10,725.
37. One acre: 43,560 sq ft.
38. Not a federal Fair Housing protected class: Age.
39. A first chance to buy before owner sells to someone else: Right of first refusal.
40. Panic selling due to entry/prospective entry of protected/minority persons: Blockbusting.
41. Appointed associates in intermediary may: give advice and opinions to their respective parties.
42. ADA question in thread: All listed were requirements of ADA, depending on exact answer choices.
43. Lease for fixed period: Estate for years.
44. Promulgated forms required: in all transactions except when form prepared by property owner or property owner's attorney / authorized exception.
45. Question answer stored: All of these are true.
46. Government regulation of property use: Police power.
47. Question answer stored: A government building.
48. Depreciation from outside factors: External/economic obsolescence.
49. Loan covering more than one parcel/property: Blanket mortgage.
50. Government taking/damage without formal condemnation suit by owner: Inverse condemnation.
51. Question answer stored: Mills.
52. False/misleading/deceptive acts: Deceptive Trade Practices Act.
53. Question answer stored: All of these are benefits.
54. Credit discrimination law: Equal Credit Opportunity Act.
55. External obsolescence factors: market cycles, economic forces, political actions.
56. Secondary market participant: Fannie Mae.
57. ECOA prohibits discrimination based on age: Equal Credit Opportunity Act.
58. TREC complaint filing time in thread: 4 years from incident.
59. Question answer stored: $3,277.50.
60. Disclosure fiduciary duty: disclosing all known facts pertaining to a property to a client.

## Response Rules for the Website Search Bar
- Answer directly and simply.
- For Texas real estate law/current licensing/current TREC rules, use web search and cite official/current sources where available.
- Do not provide legal advice; say "for exam purposes" or "generally" where appropriate.
- When answering math, show the formula and final answer.
- When source conflict exists, favor current official law/TREC/HUD/CFPB sources over embedded study notes.
- Use embedded artifact knowledge for AxelAi PropOS project questions.
- Do not claim the user's private ChatGPT thread is accessible to the public website. This knowledge is copied into the backend prompt; future thread updates require updating this file.
