
AXELAI PROPOS SEARCH BAR — REAL BACKEND VERSION

This is not a mockup.
It is a simple search bar frontend plus a Netlify serverless backend.

FILES
- index.html
  The SpaceX-style search bar only.
- netlify/functions/ask.js
  Backend that sends the user's question, your embedded artifact knowledge, and live web search access to the OpenAI Responses API.
- netlify/functions/knowledge-base.md
  Copied project/thread knowledge used by the bot.
- netlify.toml
  Netlify deployment config.

SETUP
1. Upload this folder to Netlify.
2. In Netlify, add environment variable:
   OPENAI_API_KEY = your OpenAI API key
3. Optional:
   OPENAI_MODEL = gpt-5.5
   ALLOWED_ORIGIN = your website domain
4. Deploy.

GODADDY / EXISTING WEBSITE
A plain GoDaddy HTML block cannot securely call OpenAI or search the internet by itself because that would expose your API key.
Deploy the included Netlify backend, then either:
- Use the full index.html on Netlify, or
- Paste the search bar into GoDaddy and set:
  window.AXEL_AI_API_ENDPOINT = "https://YOUR-NETLIFY-SITE.netlify.app/.netlify/functions/ask";

UPDATE ARTIFACT KNOWLEDGE
Edit netlify/functions/knowledge-base.md when you add new questions, spreadsheet facts, PropOS pages, or Texas RE notes.
